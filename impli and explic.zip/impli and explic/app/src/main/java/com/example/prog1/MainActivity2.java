package com.example.prog1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        TextView name = findViewById(R.id.name);

        name.setText(getIntent().getExtras().get("name").toString());


        Button dail = findViewById(R.id.button);
        EditText phno = findViewById(R.id.phno);

        dail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String num = phno.getText().toString();

                //7893492828 -> tel:7893492828 -> Uri("tel:7893492828")
                Uri x = Uri.parse("tel:"+num);

                Intent i = new Intent(Intent.ACTION_DIAL, x);
                startActivity(i);

            }
        });
    }
}